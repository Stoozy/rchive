# rzip
Open Source zip file manager written in rust.
